<div class="row form-group bottom-border user-restriction-item">
    <div class="col-lg-4 col-md-8 col-sm-12">
        <?= $name ?? '' ?>
    </div>
    <div class="col-lg-4 col-md-8 col-sm-12">
        <?= $value_text ?? '' ?>
    </div>
    <div class="col-lg-2 col-md-3 col-sm-12">
        <?= $cost ?? '' ?>
    </div>
</div>