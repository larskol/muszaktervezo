<div class="row">
    <div class="col-12 text-center">
        <h1>404</h1>
        <h2><?= lang("Site.site404NotFound") ?></h2>
        <p><a href="<?=base_url() ?>"><?= lang("Site.siteBackToMainPage") ?></a></p>
    </div>
</div>