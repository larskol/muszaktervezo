<?php
    return [
        'tableHeaderHashtag' => '#',
        'tableHeaderID' => 'ID',
        'tableHeaderName' => 'Név',
        'tableHeaderCreatedAt' => 'Létrehozás dátuma',
        'tableHeaderUpdatedAt' => 'Módosítás dátuma',
        'tableHeaderBusinessHoursStart' => 'Munkaidó kezdete',
        'tableHeaderBusinessHoursEnd' => 'Munkaidó vége',
        'tableHeaderCost' => 'Költség (tallér)',
        'tableHeaderEmail' => 'Email',
        'tableHeaderWeeklyWorkHours' => 'Heti munkaóra',
        'tableHeaderPaidAnnualLeave' => 'Éves szabadság',
        'tableHeaderBonusPoint' => 'Tallér',
        'tableHeaderExperienceYear' => 'Tapasztalat (év)',
        'tableHeaderDate' => 'Dátum',
        'tableHeaderDay' => 'Nap',
        'tableHeaderKnowledge' => 'Ismeret',
        'tableHeaderKnowledgeLevel' => 'Tudásszint',
        'tableHeaderAmount' => 'Létszám',
        'tableHeaderDepartment' => 'Részleg',
        'tableHeaderRole' => 'Jogosultság'
    ];