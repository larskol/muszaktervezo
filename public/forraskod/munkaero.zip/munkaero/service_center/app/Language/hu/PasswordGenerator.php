<?php
    return [
        'pwGenPasswordGenerator' => 'Jelszó generátor',
        'pwGenPassword' => 'Jelszó',
        'pwGenPasswordLength' => 'Jelszó hossza',
        'pwGenPasswordSet' => 'Beállít',
        'pwGenPasswordEmpty' => 'Kiürít',
        'pwGenPasswordGenerate' => 'Generál',
        'pwGenUseNumbers' => 'Számok',
        'pwGenUseSpecialCharacters' => 'Speciális karakterek'
    ];