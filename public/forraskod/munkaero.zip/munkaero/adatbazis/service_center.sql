-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2021. Ápr 18. 23:03
-- Kiszolgáló verziója: 10.4.17-MariaDB
-- PHP verzió: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `service_center`
--
CREATE DATABASE IF NOT EXISTS service_center;
USE service_center;
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `capacity_demand`
--

CREATE TABLE `capacity_demand` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `day` date NOT NULL,
  `department_id` int(10) UNSIGNED NOT NULL,
  `shift_id` int(10) UNSIGNED NOT NULL,
  `knowledge_id` int(10) UNSIGNED NOT NULL COMMENT 'Ha 0 akkor annyi ember kell, különben az adott tudásból kell annyi',
  `knowledge_level_id` int(10) UNSIGNED DEFAULT NULL COMMENT '(Legalább) ilyen szint szükséges az adott tudásból, ha null, akkor mindegy a szint',
  `amount` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `capacity_demand`
--

INSERT INTO `capacity_demand` (`id`, `day`, `department_id`, `shift_id`, `knowledge_id`, `knowledge_level_id`, `amount`, `created_at`, `updated_at`) VALUES
(12, '2021-05-03', 1, 1, 1, NULL, 2, '2021-04-12 14:24:54', '2021-04-12 14:26:01'),
(13, '2021-05-04', 1, 1, 1, NULL, 2, '2021-04-12 14:24:54', '2021-04-12 14:26:12'),
(14, '2021-05-05', 1, 1, 1, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(15, '2021-05-06', 1, 1, 1, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(16, '2021-05-07', 1, 1, 1, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(17, '2021-05-10', 1, 1, 7, 3, 2, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(18, '2021-05-11', 1, 1, 7, 3, 2, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(19, '2021-05-12', 1, 1, 7, NULL, 2, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(20, '2021-05-13', 1, 1, 7, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(21, '2021-05-14', 1, 1, 7, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(22, '2021-05-17', 1, 1, 9, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(23, '2021-05-18', 1, 1, 9, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(24, '2021-05-19', 1, 1, 9, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(25, '2021-05-20', 1, 1, 9, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(26, '2021-05-21', 1, 1, 9, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(27, '2021-05-24', 1, 1, 9, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(28, '2021-05-25', 1, 1, 9, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(29, '2021-05-26', 1, 1, 9, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(30, '2021-05-27', 1, 1, 9, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(31, '2021-05-28', 1, 1, 9, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(32, '2021-05-17', 1, 1, 8, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(33, '2021-05-18', 1, 1, 8, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(34, '2021-05-19', 1, 1, 8, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(35, '2021-05-20', 1, 1, 8, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(36, '2021-05-21', 1, 1, 8, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(37, '2021-05-24', 1, 1, 8, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(38, '2021-05-25', 1, 1, 8, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(39, '2021-05-26', 1, 1, 8, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(40, '2021-05-27', 1, 1, 8, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(41, '2021-05-28', 1, 1, 8, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(42, '2021-05-24', 1, 1, 2, 3, 2, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(43, '2021-05-25', 1, 1, 2, 3, 2, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(44, '2021-05-26', 1, 1, 2, 3, 2, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(45, '2021-05-27', 1, 1, 2, 3, 2, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(46, '2021-05-28', 1, 1, 2, 3, 2, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(47, '2021-05-17', 1, 1, 6, 3, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(48, '2021-05-18', 1, 1, 6, 3, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(49, '2021-05-19', 1, 1, 6, 3, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(50, '2021-05-20', 1, 1, 6, NULL, 2, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(51, '2021-05-21', 1, 1, 6, NULL, 2, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(52, '2021-05-06', 1, 1, 13, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(53, '2021-05-07', 1, 1, 13, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(54, '2021-05-10', 1, 1, 13, 3, 2, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(55, '2021-05-11', 1, 1, 13, 3, 2, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(56, '2021-05-12', 1, 1, 13, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(57, '2021-05-03', 1, 1, 3, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(58, '2021-05-04', 1, 1, 3, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(59, '2021-05-05', 1, 1, 3, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(60, '2021-05-06', 1, 1, 3, 4, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(61, '2021-05-03', 1, 1, 11, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(62, '2021-05-04', 1, 1, 11, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(63, '2021-05-05', 1, 1, 11, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(64, '2021-05-06', 1, 1, 11, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(65, '2021-05-07', 1, 1, 11, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(66, '2021-05-10', 1, 1, 12, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(67, '2021-05-11', 1, 1, 12, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(68, '2021-05-12', 1, 1, 12, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(69, '2021-05-13', 1, 1, 12, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(70, '2021-05-14', 1, 1, 12, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(71, '2021-05-17', 1, 1, 12, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(72, '2021-05-18', 1, 1, 12, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(73, '2021-05-19', 1, 1, 12, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(74, '2021-05-20', 1, 1, 12, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(75, '2021-05-21', 1, 1, 12, NULL, 1, '2021-04-12 14:24:54', '2021-04-12 14:24:54'),
(76, '2021-05-31', 1, 1, 20, NULL, 2, '2021-04-12 14:27:27', '2021-04-12 14:27:27'),
(77, '2021-05-31', 1, 1, 5, 5, 1, '2021-04-12 14:27:56', '2021-04-12 14:27:56'),
(78, '2021-05-31', 1, 1, 10, NULL, 1, '2021-04-12 14:29:18', '2021-04-12 14:29:18'),
(79, '2021-05-31', 1, 1, 11, NULL, 1, '2021-04-12 14:29:32', '2021-04-12 14:29:32'),
(80, '2021-05-03', 28, 6, 17, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(81, '2021-05-04', 28, 6, 17, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(82, '2021-05-05', 28, 6, 17, NULL, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(83, '2021-05-06', 28, 6, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(84, '2021-05-07', 28, 6, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(85, '2021-05-10', 28, 7, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(86, '2021-05-11', 28, 7, 19, NULL, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(87, '2021-05-12', 28, 7, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(88, '2021-05-13', 28, 7, 17, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(89, '2021-05-14', 28, 7, 17, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(90, '2021-05-17', 28, 1, 17, NULL, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(91, '2021-05-18', 28, 1, 17, NULL, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(92, '2021-05-19', 28, 1, 17, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(93, '2021-05-20', 28, 1, 17, 4, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(94, '2021-05-21', 28, 1, 17, 4, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(95, '2021-05-24', 28, 1, 17, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(96, '2021-05-25', 28, 1, 17, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(97, '2021-05-26', 28, 1, 17, NULL, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(98, '2021-05-27', 28, 1, 17, NULL, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(99, '2021-05-28', 28, 1, 17, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(100, '2021-05-03', 28, 1, 17, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(101, '2021-05-04', 28, 1, 17, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(102, '2021-05-05', 28, 1, 17, NULL, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(103, '2021-05-06', 28, 1, 19, 4, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(104, '2021-05-07', 28, 1, 19, 4, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(105, '2021-05-10', 28, 1, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(106, '2021-05-11', 28, 1, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(107, '2021-05-12', 28, 1, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(108, '2021-05-13', 28, 1, 17, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(109, '2021-05-14', 28, 1, 17, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(110, '2021-05-08', 28, 6, 19, 3, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(111, '2021-05-03', 28, 1, 14, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(112, '2021-05-04', 28, 1, 14, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(113, '2021-05-05', 28, 1, 14, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(114, '2021-05-06', 28, 1, 14, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(115, '2021-05-07', 28, 1, 14, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(116, '2021-05-10', 28, 1, 14, NULL, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(117, '2021-05-11', 28, 1, 14, NULL, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(118, '2021-05-19', 28, 5, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(119, '2021-05-26', 28, 5, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(120, '2021-05-15', 28, 6, 19, 3, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(121, '2021-05-22', 28, 6, 19, 3, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(122, '2021-05-29', 28, 6, 19, 3, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(123, '2021-05-26', 28, 1, 14, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(124, '2021-05-27', 28, 1, 14, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(125, '2021-05-28', 28, 1, 14, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(126, '2021-05-17', 28, 1, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(127, '2021-05-18', 28, 1, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(128, '2021-05-19', 28, 1, 19, NULL, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(129, '2021-05-20', 28, 1, 19, NULL, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(130, '2021-05-21', 28, 1, 19, NULL, 2, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(131, '2021-05-24', 28, 1, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(132, '2021-05-25', 28, 1, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(133, '2021-05-26', 28, 1, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(134, '2021-05-27', 28, 1, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(135, '2021-05-28', 28, 1, 19, NULL, 1, '2021-04-12 15:28:17', '2021-04-12 15:28:17'),
(136, '2021-05-03', 28, 1, 19, NULL, 1, '2021-04-12 15:30:18', '2021-04-12 15:30:18'),
(137, '2021-05-04', 28, 1, 19, NULL, 1, '2021-04-12 15:30:33', '2021-04-12 15:30:33'),
(138, '2021-05-31', 28, 1, 14, NULL, 1, '2021-04-12 15:59:20', '2021-04-12 15:59:20'),
(139, '2021-05-31', 28, 1, 17, NULL, 1, '2021-04-12 15:59:29', '2021-04-12 15:59:29'),
(140, '2021-05-31', 28, 1, 19, NULL, 1, '2021-04-12 15:59:40', '2021-04-12 15:59:40');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `departments`
--

CREATE TABLE `departments` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `departments`
--

INSERT INTO `departments` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'IT részleg', '2021-02-25 21:37:15', NULL, NULL),
(28, 'Ügyfélszolgálat', '2021-04-07 15:28:41', '2021-04-07 18:47:23', NULL),
(29, 'Teszt', '2021-04-08 13:54:20', '2021-04-08 13:54:33', '2021-04-08 13:54:33');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `knowledge`
--

CREATE TABLE `knowledge` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `departments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`departments`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `knowledge`
--

INSERT INTO `knowledge` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`, `departments`) VALUES
(1, 'PHP', '2021-02-25 21:37:15', '2021-04-07 15:31:10', NULL, '[\"1\"]'),
(2, 'Javascript', '2021-02-25 21:37:15', '2021-03-24 19:30:11', NULL, '[\"1\"]'),
(3, 'C', '2021-02-25 21:37:15', '2021-03-24 19:30:16', NULL, '[\"1\"]'),
(4, 'C++', '2021-02-25 21:37:15', '2021-03-24 19:30:22', NULL, '[\"1\"]'),
(5, 'C#', '2021-02-25 21:37:15', '2021-03-24 19:30:27', NULL, '[\"1\"]'),
(6, 'NodeJS', '2021-02-25 21:37:15', '2021-03-24 19:30:38', NULL, '[\"1\"]'),
(7, 'Python', '2021-02-25 21:37:15', '2021-03-24 19:30:43', NULL, '[\"1\"]'),
(8, 'Frontend', '2021-02-25 21:37:15', '2021-04-12 13:55:01', NULL, '[\"1\"]'),
(9, '.NET', '2021-02-25 21:37:15', '2021-04-12 13:55:29', NULL, '[\"1\"]'),
(10, 'AWS', '2021-02-25 21:37:15', '2021-03-24 19:31:07', NULL, '[\"1\"]'),
(11, 'Linux rendszergazda', '2021-02-25 21:37:15', '2021-04-08 14:29:30', NULL, '[\"1\"]'),
(12, 'Windows rendszergazda', '2021-02-25 21:37:15', '2021-04-08 14:29:40', NULL, '[\"1\"]'),
(13, 'SEO', '2021-02-25 21:37:15', '2021-04-12 14:23:15', NULL, '[\"1\"]'),
(14, 'MS Office', '2021-02-25 21:37:15', '2021-04-12 15:25:51', NULL, '[\"1\",\"28\"]'),
(17, 'Ügyintézés', '2021-04-07 16:17:19', '2021-04-08 14:45:51', NULL, '[\"28\"]'),
(19, 'Telefonos ügyfélszolgálat', '2021-04-08 14:41:52', '2021-04-08 14:41:52', NULL, '[\"28\"]'),
(20, 'Java', '2021-04-08 20:56:20', '2021-04-08 20:56:20', NULL, '[\"1\"]');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `knowledge_levels`
--

CREATE TABLE `knowledge_levels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `experience` int(11) NOT NULL COMMENT 'Tapasztalati szint',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `knowledge_levels`
--

INSERT INTO `knowledge_levels` (`id`, `name`, `experience`, `display_order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Kezdő', 0, 1, '2021-02-25 21:37:15', '2021-04-07 15:32:10', NULL),
(2, 'Junior', 1, 2, '2021-02-25 21:37:15', NULL, NULL),
(3, 'Medior', 3, 3, '2021-02-25 21:37:15', NULL, NULL),
(4, 'Senior', 5, 4, '2021-02-25 21:37:15', NULL, NULL),
(5, 'Expert', 8, 5, '2021-02-25 21:37:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2021-02-15-170030', 'App\\Database\\Migrations\\CreateTables', 'default', 'App', 1614285431, 1),
(2, '2021-03-12-182200', 'App\\Database\\Migrations\\RestrictionsDropColumn', 'default', 'App', 1615573382, 2),
(3, '2021-03-16-203815', 'App\\Database\\Migrations\\UserKnowledgeLevelsDropColumn', 'default', 'App', 1615927130, 3),
(5, '2021-03-17-221405', 'App\\Database\\Migrations\\UserSelectedRestrictionTableModification', 'default', 'App', 1616019372, 4),
(6, '2021-03-21-180644', 'App\\Database\\Migrations\\AddDepartmentsColumnToTables', 'default', 'App', 1616350113, 5),
(7, '2021-03-24-195727', 'App\\Database\\Migrations\\ModifyUserDepartments', 'default', 'App', 1616615908, 6),
(11, '2021-03-26-164835', 'App\\Database\\Migrations\\NewColumnsUserRestrictions', 'default', 'App', 1616793262, 7),
(13, '2021-04-01-195551', 'App\\Database\\Migrations\\ChangeUserRoleTypeEnum', 'default', 'App', 1617307377, 8),
(14, '2021-04-01-200803', 'App\\Database\\Migrations\\ChangeUserSelectedRestrictionsValueType', 'default', 'App', 1617307878, 9),
(16, '2021-04-05-133837', 'App\\Database\\Migrations\\ChangeCapacityDemandScheduleDayToDate', 'default', 'App', 1617646480, 10);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `restrictions`
--

CREATE TABLE `restrictions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `cost` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `input_type` varchar(50) NOT NULL DEFAULT 'input',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `restrictions`
--

INSERT INTO `restrictions` (`id`, `name`, `cost`, `active`, `display_order`, `input_type`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Ebben a műszakban szeretnék dolgozni', 50, 1, 0, 'shifts', '2021-04-09 18:05:11', '2021-04-09 18:06:09', NULL),
(2, 'Ebben a műszakban nem szeretnék dolgozni', 50, 1, 0, 'shifts', '2021-04-09 18:05:11', '2021-04-09 18:06:15', NULL),
(3, 'Heti munkanapok száma', 50, 1, 0, 'input', '2021-04-09 18:05:11', '2021-04-09 18:06:30', NULL),
(4, 'Heti egymás utáni munkanapok száma', 50, 1, 0, 'input', '2021-04-09 18:05:11', '2021-04-09 18:06:35', NULL),
(5, 'Heti egymás utáni szabadnapok száma', 50, 1, 0, 'input', '2021-04-09 18:05:11', '2021-04-09 18:06:41', NULL),
(6, 'Az adott személlyel nem szeretnék együtt dolgozni', 100, 1, 0, 'users', '2021-04-09 18:05:11', '2021-04-09 18:06:49', NULL),
(7, 'Ezen a napon szabadságon vagyok', 0, 1, 0, 'input_date', '2021-04-09 18:05:11', NULL, NULL),
(8, 'A hét ezen napján nem szeretnék dolgozni', 100, 1, 0, 'custom_days', '2021-04-09 18:05:11', '2021-04-09 18:06:56', NULL),
(9, 'Az adott személlyel szeretnék együtt dolgozni', 100, 1, 0, 'users', '2021-04-09 18:05:11', '2021-04-09 18:07:02', NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `schedule`
--

CREATE TABLE `schedule` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `day` date NOT NULL,
  `department_id` int(10) UNSIGNED NOT NULL,
  `shift_id` int(10) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `schedule`
--

INSERT INTO `schedule` (`id`, `day`, `department_id`, `shift_id`, `user_id`) VALUES
(1333, '2021-05-03', 1, 1, 70),
(1334, '2021-05-03', 1, 1, 79),
(1335, '2021-05-03', 1, 1, 80),
(1336, '2021-05-04', 1, 1, 79),
(1337, '2021-05-04', 1, 1, 80),
(1338, '2021-05-04', 1, 1, 70),
(1339, '2021-05-05', 1, 1, 71),
(1340, '2021-05-05', 1, 1, 80),
(1341, '2021-05-05', 1, 1, 79),
(1342, '2021-05-06', 1, 1, 81),
(1343, '2021-05-06', 1, 1, 71),
(1344, '2021-05-06', 1, 1, 80),
(1345, '2021-05-06', 1, 1, 79),
(1346, '2021-05-07', 1, 1, 81),
(1347, '2021-05-07', 1, 1, 80),
(1348, '2021-05-07', 1, 1, 71),
(1349, '2021-05-10', 1, 1, 80),
(1350, '2021-05-10', 1, 1, 79),
(1351, '2021-05-10', 1, 1, 82),
(1352, '2021-05-10', 1, 1, 70),
(1353, '2021-05-10', 1, 1, 81),
(1354, '2021-05-11', 1, 1, 70),
(1355, '2021-05-11', 1, 1, 81),
(1356, '2021-05-11', 1, 1, 79),
(1357, '2021-05-11', 1, 1, 82),
(1358, '2021-05-11', 1, 1, 80),
(1359, '2021-05-12', 1, 1, 79),
(1360, '2021-05-12', 1, 1, 70),
(1361, '2021-05-12', 1, 1, 81),
(1362, '2021-05-12', 1, 1, 80),
(1363, '2021-05-13', 1, 1, 82),
(1364, '2021-05-13', 1, 1, 80),
(1365, '2021-05-14', 1, 1, 80),
(1366, '2021-05-14', 1, 1, 70),
(1367, '2021-05-17', 1, 1, 82),
(1368, '2021-05-17', 1, 1, 80),
(1369, '2021-05-17', 1, 1, 71),
(1370, '2021-05-17', 1, 1, 81),
(1371, '2021-05-18', 1, 1, 80),
(1372, '2021-05-18', 1, 1, 71),
(1373, '2021-05-18', 1, 1, 82),
(1374, '2021-05-18', 1, 1, 81),
(1375, '2021-05-19', 1, 1, 71),
(1376, '2021-05-19', 1, 1, 80),
(1377, '2021-05-19', 1, 1, 81),
(1378, '2021-05-19', 1, 1, 82),
(1379, '2021-05-20', 1, 1, 80),
(1380, '2021-05-20', 1, 1, 71),
(1381, '2021-05-20', 1, 1, 81),
(1382, '2021-05-20', 1, 1, 72),
(1383, '2021-05-20', 1, 1, 82),
(1384, '2021-05-21', 1, 1, 80),
(1385, '2021-05-21', 1, 1, 71),
(1386, '2021-05-21', 1, 1, 72),
(1387, '2021-05-21', 1, 1, 82),
(1388, '2021-05-21', 1, 1, 81),
(1389, '2021-05-24', 1, 1, 81),
(1390, '2021-05-24', 1, 1, 70),
(1391, '2021-05-24', 1, 1, 72),
(1392, '2021-05-24', 1, 1, 71),
(1393, '2021-05-25', 1, 1, 71),
(1394, '2021-05-25', 1, 1, 81),
(1395, '2021-05-25', 1, 1, 70),
(1396, '2021-05-25', 1, 1, 72),
(1397, '2021-05-26', 1, 1, 71),
(1398, '2021-05-26', 1, 1, 81),
(1399, '2021-05-26', 1, 1, 70),
(1400, '2021-05-26', 1, 1, 72),
(1401, '2021-05-27', 1, 1, 70),
(1402, '2021-05-27', 1, 1, 72),
(1403, '2021-05-27', 1, 1, 71),
(1404, '2021-05-27', 1, 1, 81),
(1405, '2021-05-28', 1, 1, 71),
(1406, '2021-05-28', 1, 1, 70),
(1407, '2021-05-28', 1, 1, 72),
(1408, '2021-05-28', 1, 1, 81),
(1409, '2021-05-31', 1, 1, 70),
(1410, '2021-05-31', 1, 1, 82),
(1411, '2021-05-31', 1, 1, 71),
(1412, '2021-05-31', 1, 1, 79),
(1413, '2021-05-31', 1, 1, 80),
(1414, '2021-05-03', 28, 6, 73),
(1415, '2021-05-03', 28, 1, 76),
(1416, '2021-05-03', 28, 1, 74),
(1417, '2021-05-03', 28, 1, 75),
(1418, '2021-05-04', 28, 1, 76),
(1419, '2021-05-04', 28, 1, 77),
(1420, '2021-05-04', 28, 6, 73),
(1421, '2021-05-04', 28, 1, 74),
(1422, '2021-05-05', 28, 1, 76),
(1423, '2021-05-05', 28, 1, 73),
(1424, '2021-05-05', 28, 6, 77),
(1425, '2021-05-05', 28, 6, 74),
(1426, '2021-05-05', 28, 1, 75),
(1427, '2021-05-06', 28, 1, 74),
(1428, '2021-05-06', 28, 1, 75),
(1429, '2021-05-06', 28, 6, 73),
(1430, '2021-05-07', 28, 1, 75),
(1431, '2021-05-07', 28, 1, 74),
(1432, '2021-05-07', 28, 6, 77),
(1433, '2021-05-08', 28, 6, 74),
(1434, '2021-05-08', 28, 6, 77),
(1435, '2021-05-10', 28, 7, 73),
(1436, '2021-05-10', 28, 1, 77),
(1437, '2021-05-10', 28, 1, 75),
(1438, '2021-05-10', 28, 1, 74),
(1439, '2021-05-11', 28, 7, 73),
(1440, '2021-05-11', 28, 7, 74),
(1441, '2021-05-11', 28, 1, 75),
(1442, '2021-05-11', 28, 1, 77),
(1443, '2021-05-12', 28, 1, 76),
(1444, '2021-05-12', 28, 7, 73),
(1445, '2021-05-13', 28, 1, 75),
(1446, '2021-05-13', 28, 7, 73),
(1447, '2021-05-14', 28, 1, 75),
(1448, '2021-05-14', 28, 7, 73),
(1449, '2021-05-15', 28, 6, 74),
(1450, '2021-05-15', 28, 6, 76),
(1451, '2021-05-17', 28, 1, 76),
(1452, '2021-05-17', 28, 1, 75),
(1453, '2021-05-17', 28, 1, 73),
(1454, '2021-05-18', 28, 1, 76),
(1455, '2021-05-18', 28, 1, 75),
(1456, '2021-05-18', 28, 1, 77),
(1457, '2021-05-19', 28, 1, 75),
(1458, '2021-05-19', 28, 1, 76),
(1459, '2021-05-19', 28, 1, 74),
(1460, '2021-05-19', 28, 5, 73),
(1461, '2021-05-20', 28, 1, 75),
(1462, '2021-05-20', 28, 1, 76),
(1463, '2021-05-20', 28, 1, 74),
(1464, '2021-05-21', 28, 1, 76),
(1465, '2021-05-21', 28, 1, 77),
(1466, '2021-05-21', 28, 1, 75),
(1467, '2021-05-22', 28, 6, 74),
(1468, '2021-05-24', 28, 1, 76),
(1469, '2021-05-24', 28, 1, 74),
(1470, '2021-05-25', 28, 1, 76),
(1471, '2021-05-25', 28, 1, 77),
(1472, '2021-05-26', 28, 1, 76),
(1473, '2021-05-26', 28, 1, 73),
(1474, '2021-05-26', 28, 5, 74),
(1475, '2021-05-26', 28, 1, 75),
(1476, '2021-05-26', 28, 1, 77),
(1477, '2021-05-27', 28, 1, 76),
(1478, '2021-05-27', 28, 1, 73),
(1479, '2021-05-27', 28, 1, 75),
(1480, '2021-05-27', 28, 1, 77),
(1481, '2021-05-28', 28, 1, 76),
(1482, '2021-05-28', 28, 1, 75),
(1483, '2021-05-28', 28, 1, 77),
(1484, '2021-05-29', 28, 6, 74),
(1485, '2021-05-31', 28, 1, 76),
(1486, '2021-05-31', 28, 1, 73),
(1487, '2021-05-31', 28, 1, 74);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `shifts`
--

CREATE TABLE `shifts` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `departments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`departments`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `shifts`
--

INSERT INTO `shifts` (`id`, `name`, `start_time`, `end_time`, `display_order`, `created_at`, `updated_at`, `deleted_at`, `departments`) VALUES
(1, 'Normál műszak', '08:00:00', '16:00:00', 1, '2021-02-25 21:37:15', '2021-04-07 20:02:12', NULL, '[\"1\",\"28\"]'),
(2, 'Esti műszak', '16:00:00', '00:00:00', 2, '2021-02-25 21:37:15', '2021-04-08 14:03:02', NULL, NULL),
(3, 'Éjszakai műszak', '00:00:00', '08:00:00', 3, '2021-02-25 21:37:15', NULL, NULL, NULL),
(5, 'Nappali ügyfélszolgálat', '08:00:00', '18:00:00', 0, '2021-04-07 20:00:09', '2021-04-12 15:03:13', NULL, '[\"28\"]'),
(6, 'Délelőtt', '08:00:00', '12:00:00', 0, '2021-04-08 14:01:07', '2021-04-08 14:01:07', NULL, '[\"28\"]'),
(7, 'Délután', '12:00:00', '16:00:00', 0, '2021-04-08 14:01:24', '2021-04-08 14:09:18', NULL, '[\"28\"]');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `bonus_point` int(11) NOT NULL DEFAULT 0,
  `role` enum('admin','department_admin','user') NOT NULL DEFAULT 'user',
  `department_id` int(10) UNSIGNED DEFAULT NULL,
  `weekly_work_hours` double(10,2) NOT NULL DEFAULT 0.00,
  `paid_annual_leave` double(10,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `departments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`departments`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `firstname`, `lastname`, `bonus_point`, `role`, `department_id`, `weekly_work_hours`, `paid_annual_leave`, `created_at`, `updated_at`, `deleted_at`, `departments`) VALUES
(1, 'admin@servicecenter.com', '$2y$10$zfY1FSoYS4BT.wtprwnaDOTa0WxzGNJrsrjuxy9r5Hp2b8JOMg/jO', 'Admin', 'Admin', 0, 'admin', NULL, 0.00, 0.00, NULL, NULL, NULL, NULL),
(62, 'depadmin@servicecenter.com', '$2y$10$mtOkQBOJ5gF7TozUNStUwewZQyRAduFZXdpP3nqu6DsPD5DFAZwBO', 'Admin', 'Dep', 0, 'department_admin', NULL, 0.00, 0.00, '2021-03-24 20:23:40', '2021-04-08 17:56:24', NULL, '[\"1\",\"28\"]'),
(69, 'dep.admin@servicecenter.com', '$2y$10$NONbi8TJLTYYtWwDhi3Dc.dgMCZOVbm.d4Nxx86qd7SxZzZdL8RXO', 'Dep', 'Admin', 0, 'department_admin', NULL, 0.00, 0.00, '2021-04-07 18:55:31', '2021-04-14 20:17:04', NULL, '[\"28\"]'),
(70, 'pasztor.benjamin@sc.com', '$2y$10$dIjQJgA.iSpf3NNoZ04Zfe85TCngGeZD9U6zJkUvGq8c2QSypuoEy', 'Benjamin', 'Pásztor', 1000, 'user', 1, 40.00, 25.00, '2021-04-07 19:06:27', '2021-04-08 18:01:59', NULL, NULL),
(71, 'kovacs.sandor@sc.com', '$2y$10$S7dp4DE9Q4WviS3Ixwy5wepwmd1ebZfcFCShrO96K3pNODWhc3.Ae', 'Sándor', 'Kovács', 1000, 'user', 1, 40.00, 25.00, '2021-04-07 19:06:27', '2021-04-14 20:20:48', NULL, NULL),
(72, 'juhasz.jakab@sc.com', '$2y$10$xmypR6U1/EtnINglUIuUA.l8SJuG4UQ7T2iFQSjcVdYPUoieUhJOm', 'Jakab', 'Juhász', 1000, 'user', 1, 40.00, 25.00, '2021-04-07 19:06:27', '2021-04-14 20:20:48', NULL, NULL),
(73, 'bodnar.aniko@sc.com', '$2y$10$CQLnuuU0LYq3fsqTOQQScuF8OMj44WDMK./L5V/MQ8/42ourkYDI.', 'Anikó', 'Bodnár', 1000, 'user', 28, 20.00, 12.00, '2021-04-07 19:18:57', '2021-04-08 20:14:48', NULL, NULL),
(74, 'csatar.eszter@sc.com', '$2y$10$N88Mwcvhw.AhXFWu5cWugesooEwHlybQlWuDmnyr5SjUB/qrmxwHi', 'Eszter', 'Csatár', 1000, 'user', 28, 40.00, 28.00, '2021-04-07 19:20:17', '2021-04-07 19:43:40', NULL, NULL),
(75, 'olah.brigitta@sc.com', '$2y$10$VNImliYdnld32Fsdii9QMeJ1KMuzw2l8qaCRPjJraEgG7owy/9owK', 'Brigitta', 'Oláh', 1000, 'user', 28, 40.00, 25.00, '2021-04-07 19:25:06', '2021-04-07 19:41:32', NULL, NULL),
(76, 'varadi.gabor@sc.com', '$2y$10$FWy8N.pQo5pSSzMy9YfEYeAvQm/70msduEjARFU.3W3Anso7XVrCO', 'Gábor', 'Váradi', 1000, 'user', 28, 40.00, 25.00, '2021-04-07 19:25:06', '2021-04-07 19:41:46', NULL, NULL),
(77, 'kerekes.lajos@sc.com', '$2y$10$b10eJNCVE8CSI3QaWf8NWOPNIxmwPPJhvboAtLDkEa6F9F4sYHXG6', 'Lajos', 'Kerekes', 1000, 'user', 28, 40.00, 25.00, '2021-04-07 19:29:50', '2021-04-08 15:13:09', NULL, NULL),
(79, 'balog.antal@sc.com', '$2y$10$Qxb55EatGqPeGkPsTAttdeVoVWiPULPH5Eqp4YUqssaeVMG0ZOfBO', 'Antal', 'Balog', 1000, 'user', 1, 32.00, 20.00, '2021-04-07 19:36:14', '2021-04-14 20:18:09', NULL, NULL),
(80, 'kapolcs.norbert@sc.com', '$2y$10$vINqic25Qn1sUAvllGSJ6.EWT30xByBgLoqDhs663esM6ZkEqoOEC', 'Norbert', 'Kapolcs', 1000, 'user', 1, 40.00, 30.00, '2021-04-07 19:36:14', '2021-04-07 20:57:43', NULL, NULL),
(81, 'pal.nora@sc.com', '$2y$10$iYbMXWbTpaNIL/p9WsJAgO5sgA7jbMoug0WG9q8bVLahIapFzpmta', 'Nóra', 'Pál', 1000, 'user', 1, 40.00, 25.00, '2021-04-07 19:36:14', '2021-04-07 20:57:43', NULL, NULL),
(82, 'lukacs.hajnalka@sc.com', '$2y$10$fQJlX/sil2DuOR1ZrJ4mkOxOA0sPyMbikeOLMaX5E21.QGOrulLjC', 'Hajnalka', 'Lukács', 1000, 'user', 1, 40.00, 28.00, '2021-04-07 19:36:14', '2021-04-07 20:57:43', NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `user_knowledge_levels`
--

CREATE TABLE `user_knowledge_levels` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `knowledge_id` int(10) UNSIGNED NOT NULL,
  `knowledge_level_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `user_knowledge_levels`
--

INSERT INTO `user_knowledge_levels` (`user_id`, `knowledge_id`, `knowledge_level_id`) VALUES
(70, 1, 3),
(70, 2, 3),
(70, 13, 4),
(71, 5, 5),
(71, 9, 4),
(72, 6, 2),
(72, 2, 3),
(72, 8, 2),
(73, 14, 2),
(73, 17, 2),
(73, 19, 2),
(74, 19, 5),
(74, 14, 4),
(75, 17, 4),
(75, 14, 4),
(76, 17, 3),
(76, 19, 3),
(76, 14, 4),
(77, 17, 3),
(77, 19, 3),
(79, 10, 3),
(79, 11, 4),
(79, 7, 4),
(80, 12, 4),
(80, 11, 3),
(81, 8, 4),
(81, 2, 4),
(81, 13, 3),
(82, 7, 3),
(82, 6, 3),
(82, 2, 4),
(82, 4, 2),
(82, 3, 2),
(71, 1, 4),
(81, 6, 3),
(80, 3, 4),
(80, 4, 3),
(82, 20, 4),
(70, 20, 3),
(70, 7, 2),
(80, 13, 3),
(74, 17, 4);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `user_selected_restrictions`
--

CREATE TABLE `user_selected_restrictions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(50) NOT NULL COMMENT 'Tábla neve',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `restriction_id` int(10) UNSIGNED NOT NULL,
  `value` varchar(50) NOT NULL,
  `day_value` date DEFAULT NULL COMMENT 'adott nap',
  `week_value` date DEFAULT NULL COMMENT 'adott hét, amelyiken a kiválasztott nap van',
  `week_number` tinyint(4) DEFAULT NULL COMMENT 'adott hét, amelyiken a kiválasztott nap van',
  `value_type` enum('all','given_day','given_week') DEFAULT NULL COMMENT 'egész hónap, adott nap, adott hét',
  `bonus_point` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `user_selected_restrictions`
--

INSERT INTO `user_selected_restrictions` (`id`, `type`, `user_id`, `restriction_id`, `value`, `day_value`, `week_value`, `week_number`, `value_type`, `bonus_point`, `created_at`, `updated_at`) VALUES
(73, 'shifts', 73, 1, '6', NULL, '2021-05-03', 18, 'given_week', 50, '2021-04-09 18:15:28', '2021-04-09 18:15:28'),
(74, 'shifts', 73, 1, '7', NULL, '2021-05-10', 19, 'given_week', 50, '2021-04-09 18:16:58', '2021-04-09 18:16:58'),
(75, 'custom_days', 74, 8, '6', NULL, NULL, NULL, 'all', 100, '2021-04-09 18:18:24', '2021-04-09 18:18:24'),
(76, 'input_date', 74, 7, '2021-05-28', '2021-05-28', NULL, NULL, 'given_day', 0, '2021-04-09 18:18:50', '2021-04-09 18:18:50'),
(77, 'input_date', 74, 7, '2021-05-27', '2021-05-27', NULL, NULL, 'given_day', 0, '2021-04-09 18:19:02', '2021-04-09 18:19:02'),
(78, 'input', 75, 3, '5', NULL, '2021-05-14', 19, 'given_week', 50, '2021-04-09 18:19:53', '2021-04-09 18:19:53'),
(79, 'shifts', 75, 1, '1', NULL, '2021-05-21', 20, 'given_week', 50, '2021-04-09 18:21:13', '2021-04-09 18:21:13'),
(80, 'users', 74, 9, '73', NULL, NULL, NULL, 'all', 100, '2021-04-09 18:22:02', '2021-04-09 18:22:02'),
(83, 'input_date', 76, 7, '2021-05-07', '2021-05-07', NULL, NULL, 'given_day', 0, '2021-04-09 18:25:26', '2021-04-09 18:25:26'),
(84, 'input_date', 76, 7, '2021-05-06', '2021-05-06', NULL, NULL, 'given_day', 0, '2021-04-09 18:25:51', '2021-04-09 18:25:51'),
(85, 'input_date', 76, 7, '2021-05-10', '2021-05-10', NULL, NULL, 'given_day', 0, '2021-04-09 18:26:05', '2021-04-09 18:26:05'),
(86, 'input_date', 76, 7, '2021-05-11', '2021-05-11', NULL, NULL, 'given_day', 0, '2021-04-09 18:26:15', '2021-04-09 18:26:15'),
(87, 'input_date', 76, 7, '2021-05-08', '2021-05-08', NULL, NULL, 'given_day', 0, '2021-04-09 18:28:15', '2021-04-09 18:28:15'),
(89, 'custom_days', 70, 8, '3', NULL, '2021-05-26', 21, 'given_week', 100, '2021-04-09 18:32:12', '2021-04-09 18:32:12'),
(90, 'input_date', 71, 7, '2021-05-03', '2021-05-03', NULL, NULL, 'given_day', 0, '2021-04-09 18:33:20', '2021-04-09 18:33:20'),
(91, 'input_date', 71, 7, '2021-05-04', '2021-05-04', NULL, NULL, 'given_day', 0, '2021-04-09 18:33:33', '2021-04-09 18:33:33'),
(92, 'input', 79, 3, '2', NULL, '2021-05-14', 19, 'given_week', 50, '2021-04-09 18:51:06', '2021-04-09 18:51:06'),
(93, 'custom_days', 79, 8, '3', NULL, '2021-05-10', 19, 'given_week', 100, '2021-04-09 18:51:40', '2021-04-09 18:51:40'),
(94, 'input_date', 82, 7, '2021-05-24', '2021-05-24', NULL, NULL, 'given_day', 0, '2021-04-09 18:53:00', '2021-04-09 18:53:00'),
(95, 'input_date', 82, 7, '2021-05-25', '2021-05-25', NULL, NULL, 'given_day', 0, '2021-04-09 18:53:10', '2021-04-09 18:53:10'),
(96, 'input_date', 82, 7, '2021-05-26', '2021-05-26', NULL, NULL, 'given_day', 0, '2021-04-09 18:53:18', '2021-04-09 18:53:18'),
(97, 'input_date', 82, 7, '2021-05-27', '2021-05-27', NULL, NULL, 'given_day', 0, '2021-04-09 18:53:27', '2021-04-09 18:53:27'),
(98, 'input_date', 82, 7, '2021-05-28', '2021-05-28', NULL, NULL, 'given_day', 0, '2021-04-09 18:53:37', '2021-04-09 18:53:37'),
(99, 'users', 71, 9, '81', NULL, NULL, NULL, 'all', 100, '2021-04-09 18:54:46', '2021-04-09 18:54:46'),
(100, 'users', 81, 9, '71', NULL, NULL, NULL, 'all', 100, '2021-04-09 18:55:17', '2021-04-09 18:55:17'),
(101, 'input', 76, 4, '4', NULL, '2021-05-24', 21, 'given_week', 50, '2021-04-12 14:41:07', '2021-04-12 14:41:07');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `capacity_demand`
--
ALTER TABLE `capacity_demand`
  ADD PRIMARY KEY (`id`),
  ADD KEY `capacity_demand_department_id_foreign` (`department_id`),
  ADD KEY `capacity_demand_shift_id_foreign` (`shift_id`),
  ADD KEY `capacity_demand_knowledge_id_foreign` (`knowledge_id`),
  ADD KEY `capacity_demand_knowledge_level_id_foreign` (`knowledge_level_id`);

--
-- A tábla indexei `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `knowledge`
--
ALTER TABLE `knowledge`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `knowledge_levels`
--
ALTER TABLE `knowledge_levels`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `restrictions`
--
ALTER TABLE `restrictions`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `schedule_department_id_foreign` (`department_id`),
  ADD KEY `schedule_shift_id_foreign` (`shift_id`),
  ADD KEY `schedule_user_id_foreign` (`user_id`);

--
-- A tábla indexei `shifts`
--
ALTER TABLE `shifts`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `users_department_id_foreign` (`department_id`);

--
-- A tábla indexei `user_knowledge_levels`
--
ALTER TABLE `user_knowledge_levels`
  ADD KEY `user_knowledge_levels_user_id_foreign` (`user_id`),
  ADD KEY `user_knowledge_levels_knowledge_id_foreign` (`knowledge_id`),
  ADD KEY `user_knowledge_levels_knowledge_level_id_foreign` (`knowledge_level_id`);

--
-- A tábla indexei `user_selected_restrictions`
--
ALTER TABLE `user_selected_restrictions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_selected_restrictions_restriction_id_foreign` (`restriction_id`),
  ADD KEY `user_selected_restrictions_user_id_foreign` (`user_id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `capacity_demand`
--
ALTER TABLE `capacity_demand`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;

--
-- AUTO_INCREMENT a táblához `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT a táblához `knowledge`
--
ALTER TABLE `knowledge`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT a táblához `knowledge_levels`
--
ALTER TABLE `knowledge_levels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT a táblához `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT a táblához `restrictions`
--
ALTER TABLE `restrictions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT a táblához `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1488;

--
-- AUTO_INCREMENT a táblához `shifts`
--
ALTER TABLE `shifts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT a táblához `user_selected_restrictions`
--
ALTER TABLE `user_selected_restrictions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `capacity_demand`
--
ALTER TABLE `capacity_demand`
  ADD CONSTRAINT `capacity_demand_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `capacity_demand_knowledge_id_foreign` FOREIGN KEY (`knowledge_id`) REFERENCES `knowledge` (`id`),
  ADD CONSTRAINT `capacity_demand_knowledge_level_id_foreign` FOREIGN KEY (`knowledge_level_id`) REFERENCES `knowledge_levels` (`id`),
  ADD CONSTRAINT `capacity_demand_shift_id_foreign` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`);

--
-- Megkötések a táblához `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `schedule_shift_id_foreign` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`),
  ADD CONSTRAINT `schedule_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Megkötések a táblához `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);

--
-- Megkötések a táblához `user_knowledge_levels`
--
ALTER TABLE `user_knowledge_levels`
  ADD CONSTRAINT `user_knowledge_levels_knowledge_id_foreign` FOREIGN KEY (`knowledge_id`) REFERENCES `knowledge` (`id`),
  ADD CONSTRAINT `user_knowledge_levels_knowledge_level_id_foreign` FOREIGN KEY (`knowledge_level_id`) REFERENCES `knowledge_levels` (`id`),
  ADD CONSTRAINT `user_knowledge_levels_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Megkötések a táblához `user_selected_restrictions`
--
ALTER TABLE `user_selected_restrictions`
  ADD CONSTRAINT `user_selected_restrictions_restriction_id_foreign` FOREIGN KEY (`restriction_id`) REFERENCES `restrictions` (`id`),
  ADD CONSTRAINT `user_selected_restrictions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
