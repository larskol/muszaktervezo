Development environment:
Visual Studio Code: https://code.visualstudio.com/download

Xampp - the attached installer, Control Panel v3.2.4 (https://www.apachefriends.org/hu/download.html)
Webserver: Apache/2.4.46 (Win64) OpenSSL/1.1.1h PHP/7.4.14
Database server version: 10.4.17-MariaDB - mariadb.org binary distribution
Database client version: libmysql - mysqlnd 7.4.14
PHP version: 7.4.14

The following extensions have to be installed on the server:
php-json
php-mysqlnd
php-xml

The following php extensions have to be enabled in the php.ini file:
intl
mbstring

Running the project:
1. Copy the 'service_center' folder to any location
2. Start the database server
3. Import the attached 'adatbazis/service_center.sql' database (it tries to create the empty database first, if it does not exist)
4. Set the appropriate username, password in the .env file in the 'service_center' folder (line 55-59)

database.default.hostname = localhost
database.default.database = service_center
database.default.username = 
database.default.password = 
database.default.DBDriver = MySQLi

5. Open the 'service_center' folder in Command Prompt (CMD)
6. Start the Local Development Server with the following command: php spark serve
7. The site is available on the following URL: http:\\localhost:8080

Login information:
Admin
email: admin@servicecenter.com
password: FDnajAhLhewmSQ8

Department admin
email: depadmin@servicecenter.com
password: ;BbD@444m6

Another department admin
email: dep.admin@servicecenter.com
password: 9Le$2$1*

Each user has the following password for ease of use: Jelszo12345